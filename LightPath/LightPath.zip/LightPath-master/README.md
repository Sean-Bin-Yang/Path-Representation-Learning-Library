# LightPath: lightweight and scalable path representation learning 

For the code, Please check the zip file. Thanks.

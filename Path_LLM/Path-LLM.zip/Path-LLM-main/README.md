# Path-LLM
## Requirements
- Ubuntu OS (18.04.5 are tested)
- Python == 3.9
- torch==2.1.1
## Data Format
We prepare the sample data [sample](main/sample), you can replace it with your own data to run Path-LLM.
## Run Path-LLM
```
cd Path-LLM
bash train_eta.sh
```

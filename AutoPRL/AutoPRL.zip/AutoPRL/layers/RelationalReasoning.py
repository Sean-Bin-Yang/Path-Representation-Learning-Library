import torch
import math


class RelationalReasoning(torch.nn.Module):
  """Self-Supervised Relational Reasoning.
  Essential implementation of the method, which uses
  the 'cat' aggregation function (the most effective),
  and can be used with any backbone.
  """
  def __init__(self, feature_size=512):
    super(RelationalReasoning, self).__init__()
    self.feature_size = feature_size
    self.relation_head = torch.nn.Sequential(
                             torch.nn.Linear(self.feature_size*2, 512),
                             torch.nn.BatchNorm1d(512),
                             torch.nn.LeakyReLU(),
                             torch.nn.Linear(512, 1))

  def forward(self, features, K=2):
    relation_pairs_list = list()
    targets_list = list()
    size = int(features.shape[0] / K)
    shifts_counter=1
    for index_1 in range(0, size*K, size):
      for index_2 in range(index_1+size, size*K, size):
        # Using the 'cat' aggregation function by default
        pos_pair = torch.cat([features[index_1:index_1+size], 
                              features[index_2:index_2+size]], 1)
        # Shuffle without collisions by rolling the mini-batch (negatives)
        neg_pair = torch.cat([
                     features[index_1:index_1+size], 
                     torch.roll(features[index_2:index_2+size], 
                     shifts=shifts_counter, dims=0)], 1)
        relation_pairs_list.append(pos_pair)
        relation_pairs_list.append(neg_pair)
        targets_list.append(torch.ones(size, dtype=torch.float32))
        targets_list.append(torch.zeros(size, dtype=torch.float32))
        shifts_counter+=1
        if(shifts_counter>=size): 
            shifts_counter=1 # avoid identity pairs
    relation_pairs = torch.cat(relation_pairs_list, 0)
    targets = torch.cat(targets_list, 0)
    return relation_pairs, targets,self.relation_head(relation_pairs)

#   def train(self, tot_epochs, train_loader):
#     optimizer = torch.optim.Adam([
#                   {'params': self.backbone.parameters()},
#                   {'params': self.relation_head.parameters()}])                               
#     BCE = torch.nn.BCEWithLogitsLoss()
#     self.backbone.train()
#     self.relation_head.train()
#     for epoch in range(tot_epochs):
#       # the real target is discarded (unsupervised)
#       for i, (data_augmented, _) in enumerate(train_loader):
#         K = len(data_augmented) # tot augmentations
#         x = torch.cat(data_augmented, 0)
#         optimizer.zero_grad()              
#         # forward pass (backbone)
#         features = self.backbone(x) 
#         # aggregation function
#         relation_pairs, targets = self.aggregate(features, K)
#         # forward pass (relation head)
#         score = self.relation_head(relation_pairs).squeeze()        
#         # cross-entropy loss and backward
#         loss = BCE(score, targets)
#         loss.backward()
#         optimizer.step()            
#         # estimate the accuracy
#         predicted = torch.round(torch.sigmoid(score))
#         correct = predicted.eq(targets.view_as(predicted)).sum()
#         accuracy = (100.0 * correct / float(len(targets)))
        
#         if(i%100==0):
#           print('Epoch [{}][{}/{}] loss: {:.5f}; accuracy: {:.2f}%' \
#             .format(epoch+1, i+1, len(train_loader)+1, 
#                     loss.item(), accuracy.item()))

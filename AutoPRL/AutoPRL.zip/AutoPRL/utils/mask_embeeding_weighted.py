import torch 
import torch.nn as nn 
import random 
from torch.cuda.amp import autocast as autocast
from torchvision.transforms import transforms

def ShuffleIndex1(index: list, sample_ratio: float):
    sample_list = []
    if len(index) < 4:
        raise ValueError("ipnuts must be more than 4")
    else:
        remain_length = int(round(((1 - sample_ratio) * len(index))))

        # temp_index = index.copy()

        weight_ =sorted(index, reverse=True)[:remain_length]
      
        sample_list = [i+1 for i, x in enumerate(index) if x in weight_]
        mask_list =[i+1 for i, x in enumerate(index) if x not in weight_]

        assert len(sample_list) == len(index)-len(mask_list), "sample length must be same as the ratio!!!"
    return sample_list, mask_list 

def MaskEmbeeding1(token_emb, token_weight, mask_ratio):
    """get the mask embeeding after patch_emb + pos_emb
    """
    
    token_length = token_emb.shape[1]
    token_index = [ii for ii in range(1, token_length)] ##except cls token, so from 1 to len()

    sample_ =[]
    mask_ =[]
    batch_size = token_emb.shape[0]
    for i in range(batch_size):

        weigth  = torch.squeeze(token_weight[i,:],0).clone().detach().tolist()
        mask_index, sample_index = ShuffleIndex1(weigth, mask_ratio)
        mask_index_ = [x for x in mask_index]
        sample_index_ =[x for x in sample_index]
        token_sample = [0] + sample_index_
        sample_.append(token_sample)
        mask_.append(mask_index_)

    x= token_emb[torch.arange(token_emb.size(0)).unsqueeze(1), torch.LongTensor(sample_)]
    x_rest = token_emb[torch.arange(token_emb.size(0)).unsqueeze(1), torch.LongTensor(mask_)]

    return x, x_rest, torch.LongTensor(sample_), torch.LongTensor(mask_)

class UnMaskEmbeeding(nn.Module):
    """get the mask embeeding from the image -> 127 to embeeding, before the position embeeding
    """
    def __init__(self, embed_dim, in_chans, num_patches):
        super().__init__()
        self.in_chans = in_chans
        self.embed_dim = embed_dim
        self.num_patches = num_patches
     
    def forward(self, x, sample_index, x_rest, mask_index):

        sample_index_=sample_index.unsqueeze(-1).repeat(1,1,self.embed_dim)
        mask_index_ = mask_index.unsqueeze(-1).repeat(1,1,self.embed_dim)

        b, _, _ = x.shape
        x = x.float()
        x_rest=x_rest.float()
      
        decoder_embeeding = nn.Parameter(torch.zeros((b, 1 + self.num_patches, self.embed_dim),dtype=torch.float))
        # if torch.cuda.is_available():
            # decoder_embeeding=decoder_embeeding.cuda()

        with torch.no_grad():
            with autocast():

                if x.dtype == torch.float16:
                    decoder_embeeding = decoder_embeeding.half()
                    embeeding = embeeding.half()

                decoder_embeeding.scatter_add_(1,sample_index_, x)
                decoder_embeeding.scatter_add_(1,mask_index_,x_rest)
                
        return decoder_embeeding

if __name__ == '__main__':

    mask_ratio = 0.8
    a = torch.tensor(torch.randint(20,(2, 5, 8)))
    print(a)

    b = torch.tensor(torch.randint(2000,(2, 4)))

    umask =UnMaskEmbeeding(embed_dim=8,in_chans=3,num_patches=4)

    x, x_rst,sample,mask = MaskEmbeeding1(a, b, mask_ratio)

    XX= umask(x,sample,x_rst,mask)
    print(XX)